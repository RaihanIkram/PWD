// ============================================================
// JAVASCRIPT EKSTERNAL
// Website Profil Raihan Ikram Maulana
// ============================================================


// ================= 1. PESAN SAPA =================

// Mengambil elemen HTML berdasarkan id
const tombolSapa = document.getElementById("tombol-sapa");
const pesanSapa = document.getElementById("pesan-sapa");

// Fungsi untuk menampilkan pesan
function tampilkanPesan() {
    pesanSapa.textContent =
        "Halo! Terima kasih sudah mengunjungi profil saya.";
}

// Menjalankan fungsi saat tombol diklik
tombolSapa.addEventListener("click", tampilkanPesan);


// ================= 2. MODE GELAP =================

// Mengambil tombol tema dan elemen body
const tombolTema = document.getElementById("dark-mode-toggle");
const bodyHalaman = document.body;

// Fungsi untuk mengubah tema
function initDarkMode() {
    tombolTema.addEventListener("click", function () {

        const modeGelapAktif =
            bodyHalaman.classList.toggle("mode-gelap");

        if (modeGelapAktif) {
            tombolTema.textContent = "Mode Terang";
        } else {
            tombolTema.textContent = "Mode Gelap";
        }
    });
}


// ================= 3. MENU MOBILE =================

// Mengambil elemen hamburger dan menu navigasi
function initHamburgerMenu() {
    const hamburger = document.getElementById("hamburger");
    const navMenu = document.getElementById("nav-menu");
    const semuaTautanNav = document.querySelectorAll(".nav-link");

    hamburger.addEventListener("click", function () {
        hamburger.classList.toggle("hamburger-aktif");
        navMenu.classList.toggle("menu-terbuka");
    });

    // Menutup menu setelah salah satu link diklik
    semuaTautanNav.forEach(function (tautan) {
        tautan.addEventListener("click", function () {
            navMenu.classList.remove("menu-terbuka");
            hamburger.classList.remove("hamburger-aktif");
        });
    });
}


// ================= 4. EFEK NAVBAR SAAT SCROLL =================

function initNavbarScrollEffects() {
    const navbar = document.getElementById("navbar");
    const semuaSection =
        document.querySelectorAll(".section, .hero");
    const semuaTautanNav =
        document.querySelectorAll(".nav-link");

    window.addEventListener("scroll", function () {

        // Memberi bayangan pada navbar saat halaman digulir
        if (window.scrollY > 40) {
            navbar.classList.add("navbar-scrolled");
        } else {
            navbar.classList.remove("navbar-scrolled");
        }

        // Menentukan section yang sedang aktif
        let idSectionAktif = "";

        semuaSection.forEach(function (section) {

            const posisi = section.getBoundingClientRect();

            if (posisi.top <= 120 && posisi.bottom > 120) {
                idSectionAktif = section.getAttribute("id");
            }
        });

        // Memberi tanda pada link yang sesuai
        semuaTautanNav.forEach(function (tautan) {

            tautan.classList.remove("link-aktif");

            if (tautan.getAttribute("href") === "#" + idSectionAktif) {
                tautan.classList.add("link-aktif");
            }
        });
    });
}


// ================= 5. ANIMASI COUNTER =================

function jalankanAnimasiCounter() {

    const semuaCounter =
        document.querySelectorAll(".counter");

    semuaCounter.forEach(function (counter) {

        const nilaiTarget =
            parseInt(counter.dataset.target, 10);

        let nilaiSaatIni = 0;

        const kenaikanPerLangkah =
            Math.ceil(nilaiTarget / 30);

        const interval = setInterval(function () {

            nilaiSaatIni += kenaikanPerLangkah;

            if (nilaiSaatIni >= nilaiTarget) {
                nilaiSaatIni = nilaiTarget;
                clearInterval(interval);
            }

            counter.textContent = nilaiSaatIni;

        }, 30);
    });
}

function initCounterAnimation() {

    const sectionTentang =
        document.getElementById("tentang");

    let animasiSudahDijalankan = false;

    window.addEventListener("scroll", function () {

        if (animasiSudahDijalankan) {
            return;
        }

        const posisi =
            sectionTentang.getBoundingClientRect();

        if (posisi.top < window.innerHeight - 100) {
            jalankanAnimasiCounter();
            animasiSudahDijalankan = true;
        }
    });
}


// ================= 6. FILTER PROJECT =================

function initPortfolioFilter() {

    const semuaTombolFilter =
        document.querySelectorAll(".filter-btn");

    const semuaItemPortofolio =
        document.querySelectorAll(".portfolio-item");

    semuaTombolFilter.forEach(function (tombol) {

        tombol.addEventListener("click", function () {

            const kategoriDipilih =
                tombol.dataset.kategori;

            semuaItemPortofolio.forEach(function (item) {

                const cocok =
                    kategoriDipilih === "semua" ||
                    item.dataset.kategori === kategoriDipilih;

                item.classList.toggle(
                    "tersembunyi",
                    !cocok
                );
            });

            semuaTombolFilter.forEach(function (tombolLain) {
                tombolLain.classList.remove("aktif");
            });

            tombol.classList.add("aktif");
        });
    });
}


// ================= 7. SLIDER PERJALANAN BELAJAR =================

function initLearningSlider() {

    const semuaSlide =
        document.querySelectorAll(".learning-slide");

    const kontainerDots =
        document.getElementById("slide-dots");

    const tombolNext =
        document.getElementById("slide-next");

    const tombolPrev =
        document.getElementById("slide-prev");

    let indexAktif = 0;

    // Membuat dot sesuai jumlah slide
    semuaSlide.forEach(function (_, index) {

        const dot =
            document.createElement("button");

        dot.classList.add("slide-dot");
        dot.setAttribute("type", "button");

        if (index === 0) {
            dot.classList.add("dot-aktif");
        }

        dot.addEventListener("click", function () {
            tampilkanSlide(index);
        });

        kontainerDots.appendChild(dot);
    });

    const semuaDots =
        kontainerDots.querySelectorAll(".slide-dot");

    function tampilkanSlide(index) {

        semuaSlide.forEach(function (slide) {
            slide.classList.remove("slide-aktif");
        });

        semuaDots.forEach(function (dot) {
            dot.classList.remove("dot-aktif");
        });

        semuaSlide[index].classList.add("slide-aktif");
        semuaDots[index].classList.add("dot-aktif");

        indexAktif = index;
    }

    tombolNext.addEventListener("click", function () {

        const selanjutnya =
            (indexAktif + 1) % semuaSlide.length;

        tampilkanSlide(selanjutnya);
    });

    tombolPrev.addEventListener("click", function () {

        const sebelumnya =
            (indexAktif - 1 + semuaSlide.length) %
            semuaSlide.length;

        tampilkanSlide(sebelumnya);
    });

    // Slider berpindah otomatis setiap 6 detik
    setInterval(function () {

        const selanjutnya =
            (indexAktif + 1) % semuaSlide.length;

        tampilkanSlide(selanjutnya);

    }, 6000);
}


// ================= 8. ACCORDION FAQ =================

function initAccordionFAQ() {

    const semuaItemFAQ =
        document.querySelectorAll(".accordion-item");

    semuaItemFAQ.forEach(function (item) {

        const tombolPertanyaan =
            item.querySelector(".accordion-question");

        const elemenJawaban =
            item.querySelector(".accordion-answer");

        tombolPertanyaan.addEventListener(
            "click",
            function () {

                const sedangTerbuka =
                    item.classList.contains("item-terbuka");

                // Tutup semua FAQ terlebih dahulu
                semuaItemFAQ.forEach(function (itemLain) {

                    itemLain.classList.remove(
                        "item-terbuka"
                    );

                    itemLain.querySelector(
                        ".accordion-answer"
                    ).style.maxHeight = null;
                });

                // Buka FAQ yang dipilih
                if (!sedangTerbuka) {

                    item.classList.add("item-terbuka");

                    elemenJawaban.style.maxHeight =
                        elemenJawaban.scrollHeight + "px";
                }
            }
        );
    });
}


// ================= 9. TOMBOL KEMBALI KE ATAS =================

function initBackToTopButton() {

    const tombolKeAtas =
        document.getElementById("back-to-top");

    window.addEventListener("scroll", function () {

        if (window.scrollY > 500) {
            tombolKeAtas.classList.add("tombol-tampil");
        } else {
            tombolKeAtas.classList.remove("tombol-tampil");
        }
    });

    tombolKeAtas.addEventListener("click", function () {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
}


// ================= MENJALANKAN SELURUH FITUR =================

initDarkMode();
initHamburgerMenu();
initNavbarScrollEffects();
initCounterAnimation();
initPortfolioFilter();
initLearningSlider();
initAccordionFAQ();
initBackToTopButton();