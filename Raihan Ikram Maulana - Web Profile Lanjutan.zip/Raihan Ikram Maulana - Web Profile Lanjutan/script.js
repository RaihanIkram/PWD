// ===== BAGIAN 1: PESAN SAPA =====

const tombolSapa = document.getElementById("tombol-sapa");
const pesanSapa = document.getElementById("pesan-sapa");

function tampilkanPesan() {
    pesanSapa.textContent = "Halo! Terima kasih sudah mengunjungi profil saya.";
}

tombolSapa.addEventListener("click", tampilkanPesan);


// ===== BAGIAN 2: MODE GELAP =====

const tombolTema = document.getElementById("tombol-tema");
const bodyHalaman = document.body;

function ubahTema() {
    const modeGelapAktif = bodyHalaman.classList.toggle("mode-gelap");

    if (modeGelapAktif) {
        tombolTema.textContent = "Mode Terang";
    } else {
        tombolTema.textContent = "Mode Gelap";
    }
}

tombolTema.addEventListener("click", ubahTema);


// ===== BAGIAN 3: PENGHITUNG KETERTARIKAN =====

const tombolFavorit = document.getElementById("tombol-favorit");
const jumlahFavoritTampil = document.getElementById("jumlah-favorit");

let jumlahFavorit = 0;

function tambahFavorit() {
    jumlahFavorit++;
    jumlahFavoritTampil.textContent = jumlahFavorit;

    if (jumlahFavorit >= 3) {
        tombolFavorit.textContent = "Banyak yang Tertarik!";
    } else {
        tombolFavorit.textContent = "Saya Tertarik";
    }
}

tombolFavorit.addEventListener("click", tambahFavorit);